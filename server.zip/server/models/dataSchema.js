const mongoose =require("mongoose");
var Schema=mongoose.Schema;

// question model
const dataSchema = new Schema ({
    id:{
        type:Number
    },
    name:{
        type:String,
        required:true,
    },
    image:{
        type : String ,
        required: true
    },
    category:{
        type:String,   
    },
    label:{
        type:String, 
    },
    price:{
        type:String, 
    },
    description:{
        type:String
    }
})

const Data =  mongoose.model('data' , dataSchema);
module.exports = Data