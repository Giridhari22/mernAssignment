const express = require("express");
const app = express()
const PORT = 8000 
const database = require("./config/database.js")
const dataRoute = require("./routes/dataRouter.js")

app.use(express.json())
app.use("/",dataRoute)
database()


app.listen(PORT , (req,res)=>{
    console.log(`server is running on port ${PORT}`)
})