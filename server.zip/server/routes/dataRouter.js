const Router =  require("express")
const router = Router();
const func = require("../controllers/dataController.js")


// Question route api
router.get('/getData',func.getData )
router.post('/createData',func.createData)
// router.delete('/dropQuestions', question.dropQuestions)


module.exports =router;